
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <title>Homepage</title>
    <style>
        body{
            background-image: url('https://wallpapercave.com/wp/wp38040.jpg');
            width:100%;
            background-repeat: no-repeat;
            background-size: 1250px 1250px;

        }
        h1{
            color:white ;
            font: italic small-caps bold 40px/40px Georgia, serif;
            margin-left:100px;
            margin-top:200px
}

    </style>
</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="/homepage">SGH</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="/homepage">Home</a></li>
      <li><a href="/dashboard">Dashboard</a></li>
</ul>
  </div>
</nav>
<div>
<h1>Welcome To SFH Hotel Management System</h1>
    </div>

</body>
</html>
