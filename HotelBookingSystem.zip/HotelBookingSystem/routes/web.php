<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RoomtypeController;
use App\Http\Controllers\RoomController;
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\homepageController;
use App\Http\Controllers\dashboardController;
use App\Http\Controllers\loginController;

// Dashboard
Route::get('dashboard', function() {
    return view('dashboard');
});

// RoomType Routes
Route::get('dashboard/roomtype/{id}/delete',[RoomtypeController::class,'destroy']);
Route::resource('dashboard/roomtype',RoomtypeController::class);

// Room Master
Route::get('dashboard/room/{id}/delete',[RoomController::class,'destroy']);
Route::resource('dashboard/rooms',RoomController::class);

// Customer
Route::get('dashboard/customer/{id}/delete', [CustomerController::class, 'destroy']);
ROute::resource('dashboard/customer',CustomerController::class);
Route::get('homepage',[homepageController::class,'homeview']);
Route::get('dashboard',[dashboardController::class,'dashboardview']);

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
